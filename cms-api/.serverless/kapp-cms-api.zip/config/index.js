const appConfigs = require('./app');
const logging = require('./logging');

module.exports = {
  app: appConfigs,
  logging
};